.macro WAIT_VBLANK
@loop:
  bit PPUSTATUS
  bpl @loop
.endmacro