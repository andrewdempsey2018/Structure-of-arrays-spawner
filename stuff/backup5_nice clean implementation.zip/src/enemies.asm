.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
enemy_x: .res 5
enemy_y: .res 5
enemy_type: .res 5
enemy_flags: .res 5
; ----------------------------------- ;

current_enemy: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  php
  pha
  txa
  pha
  tya
  pha

  ldx #$00

loop:
  stx current_enemy
  lda enemy_flags, x
  and #%10000000
  beq next
  jsr UpdateEnemies
next:
  inx
  cpx #$05
  bne loop

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc UpdateEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy

  inc enemy_y, x

  jsr DrawEnemies

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc DrawEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy
  lda EnemyOAMIndexTable, x
  asl a
  asl a             ; multiply by 4
  tay               ; X = offset into OAM

  lda enemy_y, x
  sta $0200, y      ; Y

  lda #$02
  sta $0201, y     ; Tile

  lda #$00
  sta $0202, y      ; Attributes

  lda enemy_x, x
  sta $0203, y      ; X position

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.segment "RODATA"

EnemyOAMIndexTable:
  .byte $01,$02,$03,$04,$05