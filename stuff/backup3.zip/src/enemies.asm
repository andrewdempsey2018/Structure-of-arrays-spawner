.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
enemy_x: .res 5
enemy_y: .res 5
enemy_type: .res 5
enemy_flags: .res 5
; ----------------------------------- ;

current_enemy: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  php
  pha
  txa
  pha
  tya
  pha

  ldx #$00
  stx current_enemy

@loop:
  lda enemy_flags, x
  and #%10000000
  beq @loop
  jsr UpdateEnemies
  jsr DrawEnemies
  inx
  cpx #$05
  bne @loop

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc UpdateEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc DrawEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.segment "RODATA"