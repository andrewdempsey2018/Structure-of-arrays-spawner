.segment "ZEROPAGE"

.segment "CODE"
.export reset_handler
.proc reset_handler
  sei
  cld
  ldx #$40
  stx APU
  ldx #$FF
  txs
  inx
  stx PPUCTRL
  stx PPUMASK
  stx IRQ_ENABLE
  bit PPUSTATUS

  lda #$00
  sta sleeping
  sta buttons_held
  sta buttons_pressed

  lda #$00
  ldx #$00
ResetEnemySoALoop:
  sta enemy_x, x
  sta enemy_y, x
  sta enemy_type, x
  sta enemy_alive, x
  inx
  cpx #$04
  bne ResetEnemySoALoop

  WAIT_VBLANK

	ldx #$00
	lda #$FF
clear_oam:
	sta PPUCTRL, x ; set sprite y-positions off the screen
	inx
	inx
	inx
	inx
	bne clear_oam

  WAIT_VBLANK
  
  jmp main
.endproc