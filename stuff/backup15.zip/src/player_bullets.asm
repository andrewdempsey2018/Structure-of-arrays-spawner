.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
x_pos: .res 9
y_pos: .res 9
type: .res 9
flags: .res 9
; ----------------------------------- ;

current_player_bullet: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  SAVE_REGISTERS

  ldx #$00

loop:
  stx current_enemy
  lda enemy_flags, x
  and #%10000000
  beq next
  jsr UpdateEnemies
next:
  inx
  cpx #$05
  bne loop

  RESTORE_REGISTERS
  rts
.endproc

.proc UpdateEnemies
  SAVE_REGISTERS

  ldx current_enemy

  ;inc enemy_y, x

  jsr DrawEnemies

  RESTORE_REGISTERS
  rts
.endproc

.proc DrawEnemies
  SAVE_REGISTERS

  ldx current_enemy
  lda EnemyOAMIndexTable, x
  asl a
  asl a             ; multiply by 4
  tay               ; X = offset into OAM

  lda enemy_y, x
  sta $0200, y      ; Y

  lda #$02
  sta $0201, y     ; Tile

  lda #$02
  sta $0202, y      ; Attributes

  lda enemy_x, x
  sta $0203, y      ; X position

  RESTORE_REGISTERS
  rts
.endproc

.segment "RODATA"

EnemyOAMIndexTable:
  .byte $01,$02,$03,$04,$05