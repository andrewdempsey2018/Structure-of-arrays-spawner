ENEMY_OAM_START = $0204

.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
enemy_x: .res 5
enemy_y: .res 5
enemy_type: .res 5
enemy_flags: .res 5
enemy_state: .res 5
; ----------------------------------- ;

current_enemy: .res 1
enemy_frame_number: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  php
  pha
  txa
  pha
  tya
  pha

  ldx #$00

loop:
  stx current_enemy
  lda enemy_flags, x
  and #%10000000
  beq next
  jsr UpdateEnemies
next:
  inx
  cpx #$05
  bne loop

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc UpdateEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy

  inc enemy_frame_number
  lda enemy_frame_number
  cmp #$04
  bne :+
  lda #$00
  sta enemy_frame_number
:

  inc enemy_y, x

  jsr DrawEnemies

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc DrawEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ;;;;;
  ldy enemy_frame_number
  lda frames_lo, y
  sta scratch_03_lo
  lda frames_hi, y
  sta scratch_03_hi

  frame = scratch_03
  ;;;;;

  ldx current_enemy
  lda enemy_y, x
  sta scratch_01
  lda enemy_x, x
  sta scratch_02

  ; ----------------------------------- ;
  ; need enemy_type as a multiple of 16 as the
  ; frame_1_table is laid out in rows of 16 bytes
  ldx current_enemy
  lda enemy_type, x
  asl a
  asl a
  asl a
  asl a
  tay

  ; ----------------------------------- ;
  ; enemies are 4x4 tiles so need 16 bytes in OAM
  lda current_enemy
  asl a
  asl a
  asl a
  asl a
  tax

  lda scratch_01        ; draw top left
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  sta ENEMY_OAM_START, x

  inx                   ; draw top right
  iny
  lda scratch_01
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  clc
  adc #$08
  sta ENEMY_OAM_START, x

  inx                   ; draw bottom left
  iny
  lda scratch_01
  clc
  adc #$08
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  sta ENEMY_OAM_START, x

  inx                   ; draw bottom right
  iny
  lda scratch_01
  clc
  adc #$08
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  clc
  adc #$08
  sta ENEMY_OAM_START, x

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.segment "RODATA"

frame_1_table:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $02,$00,$03,$00,$12,$00,$13,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $04,$00,$05,$00,$14,$00,$15,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $02,$01,$03,$01,$12,$01,$13,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $04,$02,$05,$02,$14,$02,$15,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $04,$03,$05,$03,$14,$03,$15,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

frame_2_table:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $22,$00,$23,$00,$32,$00,$33,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $24,$00,$25,$00,$34,$00,$35,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $22,$01,$23,$01,$32,$01,$33,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $24,$02,$25,$02,$34,$02,$35,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $24,$03,$25,$03,$34,$03,$35,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_4:
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_3:
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_2:
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_1:
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

frames_lo:
  .byte <explosion_frame_1,<explosion_frame_2,<explosion_frame_3,<explosion_frame_4

frames_hi:
  .byte >explosion_frame_1,>explosion_frame_2,>explosion_frame_3,>explosion_frame_4