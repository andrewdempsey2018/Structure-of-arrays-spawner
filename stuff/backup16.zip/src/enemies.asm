; ----------------------------------- ;
; enemy constants
; ----------------------------------- ;
ENEMY_OAM_START = $0204

; enemy_flags
ENEMY_ALIVE = %10000000
ENEMY_FLAG_6 = %00100000
ENEMY_FLAG_5 = %00100000
ENEMY_FLAG_4 = %00010000
ENEMY_FLAG_3 = %00001000
ENEMY_FLAG_2 = %00000100
ENEMY_MOVING_RIGHT = %00000010
ENEMY_MOVING_LEFT = %00000001

; ----------------------------------- ;
; zeropage
; ----------------------------------- ;
.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
enemy_x: .res 5
enemy_y: .res 5
enemy_type: .res 5
enemy_flags: .res 5
; ----------------------------------- ;

current_enemy: .res 1
enemy_frame_number: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  SAVE_REGISTERS

  ldx #$00

loop:
  stx current_enemy
  lda enemy_flags, x
  and #ENEMY_ALIVE
  beq next
  jsr UpdateEnemies
next:
  inx
  cpx #$05
  bne loop

  RESTORE_REGISTERS
  rts
.endproc

.proc UpdateEnemies
  SAVE_REGISTERS

  ldx current_enemy

; --------------------------------------------------
; Dont process inactive enemies
; --------------------------------------------------
  lda enemy_flags, x
  and #ENEMY_ALIVE
  bne enemy_alive
  jmp done
enemy_alive:

; --------------------------------------------------
; Kill enemies that go off the bottom of the screen
; --------------------------------------------------
  lda enemy_y, x
  cmp #240
  bcc enemy_on_screen
  lda #%00000000
  sta enemy_flags, x
enemy_on_screen:

  ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

  ;;;;;
  lda #$04
  sta enemy_frame_number

  lda enemy_flags, x
  and #ENEMY_MOVING_RIGHT
  beq :+
  lda #$06
  sta enemy_frame_number
:

  lda enemy_flags, x
  and #ENEMY_MOVING_LEFT
  beq :+
  lda #$05
  sta enemy_frame_number
:
  ;;;;;

  inc enemy_y, x

  jsr DrawEnemies

done:
  RESTORE_REGISTERS
  rts
.endproc

.proc DrawEnemies
  SAVE_REGISTERS

  ;;;;;
  ldy enemy_frame_number
  lda frames_lo, y
  sta scratch_03_lo
  lda frames_hi, y
  sta scratch_03_hi

  frame = scratch_03
  ;;;;;

  ldx current_enemy
  lda enemy_y, x
  sta scratch_01
  lda enemy_x, x
  sta scratch_02

  ; ----------------------------------- ;
  ; need enemy_type as a multiple of 16 as the
  ; enemy_move_down_frames is laid out in rows of 16 bytes
  ldx current_enemy
  lda enemy_type, x
  asl a
  asl a
  asl a
  asl a
  tay

  ; ----------------------------------- ;
  ; enemies are 4x4 tiles so need 16 bytes in OAM
  lda current_enemy
  asl a
  asl a
  asl a
  asl a
  tax

  lda scratch_01        ; draw top left
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  sta ENEMY_OAM_START, x

  inx                   ; draw top right
  iny
  lda scratch_01
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  clc
  adc #$08
  sta ENEMY_OAM_START, x

  inx                   ; draw bottom left
  iny
  lda scratch_01
  clc
  adc #$08
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  sta ENEMY_OAM_START, x

  inx                   ; draw bottom right
  iny
  lda scratch_01
  clc
  adc #$08
  sta ENEMY_OAM_START, x
  inx
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (frame), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  clc
  adc #$08
  sta ENEMY_OAM_START, x

  RESTORE_REGISTERS
  rts
.endproc

.segment "RODATA"

enemy_move_down_frames:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $02,$00,$03,$00,$12,$00,$13,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $04,$00,$05,$00,$14,$00,$15,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $02,$01,$03,$01,$12,$01,$13,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $04,$02,$05,$02,$14,$02,$15,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $04,$03,$05,$03,$14,$03,$15,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

enemy_move_left_frames:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $22,$00,$23,$00,$32,$00,$33,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $24,$00,$25,$00,$34,$00,$35,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $22,$01,$23,$01,$32,$01,$33,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $24,$02,$25,$02,$34,$02,$35,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $24,$03,$25,$03,$34,$03,$35,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

enemy_move_right_frames:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $42,$00,$43,$00,$52,$00,$53,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $44,$00,$45,$00,$54,$00,$55,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $42,$01,$43,$01,$52,$01,$53,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $44,$02,$45,$02,$54,$02,$55,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $44,$03,$45,$03,$54,$03,$55,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_0:
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $06,$00,$07,$00,$16,$00,$17,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_1:
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $26,$00,$27,$00,$36,$00,$37,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_2:
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $46,$00,$47,$00,$56,$00,$57,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

explosion_frame_3:
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $66,$00,$67,$00,$76,$00,$77,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

frames_lo:
  .byte <explosion_frame_0,<explosion_frame_1,<explosion_frame_2,<explosion_frame_3,<enemy_move_down_frames,<enemy_move_left_frames,<enemy_move_right_frames

frames_hi:
  .byte >explosion_frame_0,>explosion_frame_1,>explosion_frame_2,>explosion_frame_3,>enemy_move_down_frames,>enemy_move_left_frames,>enemy_move_right_frames