ENEMY_OAM_START = $0204

.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
enemy_x: .res 5
enemy_y: .res 5
enemy_type: .res 5
enemy_flags: .res 5
; ----------------------------------- ;

current_enemy: .res 1

ptr1: .res 1
ptr2: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  php
  pha
  txa
  pha
  tya
  pha

  ldx #$00

loop:
  stx current_enemy
  lda enemy_flags, x
  and #%10000000
  beq next
  jsr UpdateEnemies
next:
  inx
  cpx #$05
  bne loop

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc UpdateEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy

  inc enemy_y, x

  jsr DrawEnemies

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc DrawEnemies
  php
  pha
  txa
  pha
  tya
  pha

  lda current_enemy
  asl a
  asl a
  asl a
  asl a
  tay

  ldx current_enemy
  lda enemy_y, x
  sta ptr1
  lda enemy_x, x
  sta ptr2

  lda current_enemy
  asl a
  asl a
  asl a
  asl a
  tax

  ;;;;;
  lda ptr1
  sta ENEMY_OAM_START, y
  iny
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  inx
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  lda ptr2
  sta ENEMY_OAM_START, y

  ;;;;;
  iny
  inx
  lda ptr1
  sta ENEMY_OAM_START, y
  iny
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  inx
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  lda ptr2
  clc
  adc #$08
  sta ENEMY_OAM_START, y

  ;;;;;
  iny
  inx
  lda ptr1
  clc
  adc #$08
  sta ENEMY_OAM_START, y
  iny
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  inx
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  lda ptr2
  sta ENEMY_OAM_START, y

  ;;;;;
  iny
  inx
  lda ptr1
  clc
  adc #$08
  sta ENEMY_OAM_START, y
  iny
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  inx
  lda enemy_types_table, x
  sta ENEMY_OAM_START, y
  iny
  lda ptr2
  clc
  adc #$08
  sta ENEMY_OAM_START, y

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.segment "RODATA"

enemy_types_table:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr
  .byte $02,$00,$03,$00,$12,$00,$13,$00,$01,$00,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $04,$00,$05,$00,$14,$00,$15,$00,$01,$00,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $02,$01,$03,$01,$12,$01,$13,$01,$01,$01,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $04,$02,$05,$02,$14,$02,$15,$02,$01,$02,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $04,$03,$05,$03,$14,$03,$15,$03,$01,$03,$FF,$FF,$FF,$FF,$FF,$FF ; type 5