ENEMY_OAM_START = $0204

.segment "ZEROPAGE"
; ----------------------------------- ;
; enemy SoA
enemy_x: .res 5
enemy_y: .res 5
enemy_type: .res 5
enemy_flags: .res 5
; ----------------------------------- ;

current_enemy: .res 1

.segment "BSS"

.segment "CODE"

.proc ProcessEnemeies
  php
  pha
  txa
  pha
  tya
  pha

  ldx #$00

loop:
  stx current_enemy
  lda enemy_flags, x
  and #%10000000
  beq next
  jsr UpdateEnemies
next:
  inx
  cpx #$05
  bne loop

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc UpdateEnemies
  php
  pha
  txa
  pha
  tya
  pha

  ldx current_enemy

  inc enemy_y, x

  jsr DrawEnemies

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.proc DrawEnemies
  php
  pha
  txa
  pha
  tya
  pha

  todo....
  so it is storing the correct frame in scratch_03
  so it is working in principle. ready to expand and refactor
  im guessing the update enemies code will determine what frame will be drawing in the draw routine
  
  lda #<frame_2_table
  sta scratch_03_lo
  lda #>frame_2_table
  sta scratch_03_hi

  ldx current_enemy
  lda enemy_y, x
  sta scratch_01
  lda enemy_x, x
  sta scratch_02

  ; ----------------------------------- ;
  ; need enemy_type as a multiple of 16 as the
  ; frame_1_table is laid out in rows of 16 bytes
  ldx current_enemy
  lda enemy_type, x
  asl a
  asl a
  asl a
  asl a
  tay

  ; ----------------------------------- ;
  ; enemies are 4x4 tiles so need 16 bytes in OAM
  lda current_enemy
  asl a
  asl a
  asl a
  asl a
  tax

  lda scratch_01        ; draw top left
  sta ENEMY_OAM_START, x
  inx
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  sta ENEMY_OAM_START, x

  inx                   ; draw top right
  iny
  lda scratch_01
  sta ENEMY_OAM_START, x
  inx
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  clc
  adc #$08
  sta ENEMY_OAM_START, x

  inx                   ; draw bottom left
  iny
  lda scratch_01
  clc
  adc #$08
  sta ENEMY_OAM_START, x
  inx
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  sta ENEMY_OAM_START, x

  inx                   ; draw bottom right
  iny
  lda scratch_01
  clc
  adc #$08
  sta ENEMY_OAM_START, x
  inx
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  iny
  lda (scratch_03), y
  sta ENEMY_OAM_START, x
  inx
  lda scratch_02
  clc
  adc #$08
  sta ENEMY_OAM_START, x

  pla
  tay
  pla
  tax
  pla
  plp

  rts
.endproc

.segment "RODATA"

frame_1_table:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $02,$00,$03,$00,$12,$00,$13,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $04,$00,$05,$00,$14,$00,$15,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $02,$01,$03,$01,$12,$01,$13,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $04,$02,$05,$02,$14,$02,$15,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $04,$03,$05,$03,$14,$03,$15,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5

frame_2_table:
  ; tiletl,attribtl,tiletr,attribtr,tilebl,attribbl,tilebr,attribbr,
  ; padding,padding,padding,padding,padding,padding,padding,padding
  .byte $22,$00,$23,$00,$32,$00,$33,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 1
  .byte $24,$00,$25,$00,$34,$00,$35,$00,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 2
  .byte $22,$01,$23,$01,$32,$01,$33,$01,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 3
  .byte $24,$02,$25,$02,$34,$02,$35,$02,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 4
  .byte $24,$03,$25,$03,$34,$03,$35,$03,$FF,$FF,$FF,$FF,$FF,$FF,$FF,$FF ; type 5